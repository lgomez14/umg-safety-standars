## UNIVERSIDAD MARIANO GALVEZ

```csharp
## INGENIERIA EN SISTEMAS
## SEGURIDAD Y AUDITORIA DE SISTEMAS

using umg_safety_standars.alumnos;

public class Alumno
{
    public string Alumno1 = "Luis Alberto Gomez Cruz";
    public string Carne1 = "5190-19-10563";

    public string Alumno2 = "Abner Ernesto Rodas Arriaga";
    public string Carne2 = "5190-17-813";

    public string Alumno3 = "Daniel Estuardo Rivas Herrera";
    public string Carne3 = "5190-19-9238";

}

[MIT](https://choosealicense.com/licenses/mit/)