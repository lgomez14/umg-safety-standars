using System.Diagnostics.CodeAnalysis;

namespace umg_database.Sources.Supplier.Models
{
    public class SupplierIdFilterModel
    {
        [ExcludeFromCodeCoverage]
        public Guid SupplierId { get; set; }
    }
}