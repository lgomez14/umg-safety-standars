﻿using System.Diagnostics.CodeAnalysis;

namespace umg_safety_standars.Source.Jwt.Models
{
    [ExcludeFromCodeCoverage]
    public class JwtAuthServiceRequestModel
    {
        public int Id { get; set; }
    }
}
