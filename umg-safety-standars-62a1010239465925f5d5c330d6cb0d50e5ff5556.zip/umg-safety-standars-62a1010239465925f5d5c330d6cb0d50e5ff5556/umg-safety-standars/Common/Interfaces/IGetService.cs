namespace umg_safety_standars.Common.Interfaces
{
    public interface IGetService
    {
        
    }
}